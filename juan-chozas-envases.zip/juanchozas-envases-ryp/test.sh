#! /bin/bash

#script para compilar y ejecutar el código
sin_cotas=0
sencillas=1
elaboradas=2

g++ -g -std=c++0x envases.cpp -o envases 

# descomentar estas llamadas para ejecutar sin entrada-salida
# primer argumento = N, segundo argumento = tipo de cotas 

# ./envases 12 $sin_cotas
# ./envases 12 $sencillas
# ./envases 12 $elaboradas
# ./envases 18 $sin_cotas
# ./envases 18 $sencillas
# ./envases 18 $elaboradas
# ./envases 24 $sin_cotas
# ./envases 24 $sencillas
# ./envases 24 $elaboradas


# descomentar esta linea para ejecutar con entrada-salida
./envases

rm envases